"""Author Hira Naveed"""

import unittest
import restuarant
import numpy as np
class TestRestuarant(unittest.TestCase):

    def test_book(self):
        self.assertEqual(restuarant.book_n("A","large"), "booked")
    def test_book2(self):
        self.assertEqual(restuarant.book_n("B", "small"), "booked")

    def test_exlarge(self):
        self.assertEqual(restuarant.book_exlarge("C", "exlarge", "22"), "booked")



if __name__ == '__main__':
    suite = unittest.TestLoader().loadTestsFromTestCase(TestRestuarant)
    unittest.TextTestRunner(verbosity=2).run(suite)
