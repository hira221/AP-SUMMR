"""Author Hira Naveed"""

import os
import numpy
import pickle
"""
1. 1 extra-large table with max capacity of 12 people.
2. 3 large tables with max capacity of 6 people.
3. 8 medium tables with max capacity of 4 people.
4. 4 small tables with max capacity of 2 people.
"""
def init():
    sides = 3
    main = 12
    desserts = 4
    soups = 2
    appetizers = 4
    tables = {}
    tables['exlarge'] = [1,12,1]
    tables['large'] = [3,6,3]
    tables['medium'] = [8,4,8]
    tables['small'] = [4,2,4]
    all_tables = [tables for x in range(0,11)]

    maxpeople = 0
    for x,y in tables.items():
        maxpeople += y[0]*y[1]

    reservations = []
    reservation = 0
    
    """Total of 25 items in menu with 4 appetizers, 2 soups, 12 main course dishes, 3 side dishes, and 4 deserts"""

    menu = {
    'appetizers':[x+1 for x in range(0,appetizers)],
    'soups':[x+1 for x in range(0,soups)],
    'main': [x+1 for x in range(0,main)],
    'sides': [x+1 for x in range(0,sides)],
    'desserts': [x+1 for x in range(0,desserts)]

    }
    return menu,reservations,reservation,all_tables


def reservation_res():
    menu,reservations,reservation,all_tables = init()
    hour = 0
    if (reservation==16):
        hour+=1
    y = "y"
    while(y!= "n"):
        y = raw_input("Want to make a reservation?")
        if(y == 'y'):
            t = raw_input("Select a table size? small, medium, large, exlarge")
            if(t not in tables.keys()):
                print "You chose wrong table size"
            elif(t!= "exlarge"):
                name = raw_input("Enter your name")
                all_tables[hour][t][2]-=1

                reservations.append((hour, t, name))
            else:
                time = raw_input("Choose your available time between "+str(hour+11)+ "hrs to "+str(hour+11+11)+ "hrs")
                name = raw_input("Enter your name")
                time = int(time) - 11
                all_tables[time][t][2]-=1
                reservations.append((time, t, name))



    with open('reservations.txt', 'w') as handle:
        pickle.dump(reservations, handle)
hour = 0
reservations = []
def book_n(name,t):
    reservations.append((hour, t, name))
    return "reserved"


def book_exlarge(name,t,time):
    reservations.append((time, t, name))
    return "reserved"
